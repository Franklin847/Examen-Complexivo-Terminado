export const environment = {
    production: true,
    API_URL_AUTHENTICATION: 'http://www.asistencia.yavirac.edu.ec/public/api/authentication/',
    API_URL_IGNUG: 'http://www.asistencia.yavirac.edu.ec/public/api/ignug/',
    API_URL_ATTENDANCE: 'http://www.asistencia.yavirac.edu.ec/public/api/attendance/',
    API_URL_JOB_BOARD: 'http://www.bolsa-empleo.yavirac.edu.ec/public/api/job_board/',
    API_URL_WEB: 'http://www.web.yavirac.edu.ec/public/api/web/',
};
