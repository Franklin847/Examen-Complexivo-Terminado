export class State {
    id: number;
    code: string;
    name: string;
    description?: string;
    state: number;

    constructor() {
        this.id = 0;
    }

}
