import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-oportunidades',
    templateUrl: './app.oportunities.component.html',
    styleUrls: ['./app.oportunities.component.scss']
})
export class AppOportunitiesComponent implements OnInit {


    constructor() { }

    ngOnInit(): void {

    }


}
