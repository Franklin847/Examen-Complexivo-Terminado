import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app.administrator',
  templateUrl: './app.administrator.component.html',
  styleUrls: ['./app.administrator.component.scss']
})
export class AppAdministratorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
