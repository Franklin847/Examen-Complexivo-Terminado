<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\Catalogue;
use Faker\Generator as Faker;

$factory->define(Catalogue::class, function (Faker $faker) {
    return [

    ];
});
