<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\SchoolPeriod;
use Faker\Generator as Faker;

$factory->define(SchoolPeriod::class, function (Faker $faker) {
    return [

    ];
});
