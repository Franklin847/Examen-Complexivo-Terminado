<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\Course;
use Faker\Generator as Faker;

$factory->define(Course::class, function (Faker $faker) {
    return [

    ];
});
