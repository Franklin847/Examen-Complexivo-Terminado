<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\Authority;
use Faker\Generator as Faker;

$factory->define(Authority::class, function (Faker $faker) {
    return [
        //
    ];
});
