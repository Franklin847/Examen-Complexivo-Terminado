<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\SetecRegistration;
use Faker\Generator as Faker;

$factory->define(SetecRegistration::class, function (Faker $faker) {
    return [
        //
    ];
});
