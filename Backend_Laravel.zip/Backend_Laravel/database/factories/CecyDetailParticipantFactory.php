<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\DetailParticipant;
use Faker\Generator as Faker;

$factory->define(DetailParticipant::class, function (Faker $faker) {
    return [
        //
    ];
});
