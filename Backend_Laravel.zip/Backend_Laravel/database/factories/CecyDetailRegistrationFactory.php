<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\DetailRegistration;
use Faker\Generator as Faker;

$factory->define(DetailRegistration::class, function (Faker $faker) {
    return [
        //
    ];
});
