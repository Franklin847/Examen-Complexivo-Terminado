<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\Planification;
use Faker\Generator as Faker;

$factory->define(Planification::class, function (Faker $faker) {
    return [
        //
    ];
});
