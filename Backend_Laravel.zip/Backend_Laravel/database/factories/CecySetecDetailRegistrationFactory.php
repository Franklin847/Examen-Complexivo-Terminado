<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Cecy\SetecDetailRegistration;
use Faker\Generator as Faker;

$factory->define(SetecDetailRegistration::class, function (Faker $faker) {
    return [
        //
    ];
});
