<?php

namespace App\Http\Controllers\Web;

use Illuminate\Http\Request;

class Texts extends Controller
{
    //
}
