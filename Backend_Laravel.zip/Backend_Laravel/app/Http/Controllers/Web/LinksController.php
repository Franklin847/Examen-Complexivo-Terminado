<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Web\Links;
use Illuminate\Http\Request;

class LinksController extends Controller
{
    //
}